// material-ui
import { useState, useEffect } from 'react';
import TextField from '@mui/material/TextField';
import Card from '@mui/material/Card';
import { number } from 'prop-types';
import Grid from '@mui/material/Unstable_Grid2';
import CreatableSelect from 'react-select/creatable';
import DataTable, { FilterComponent } from 'react-data-table-component';
import { DatePicker, Radio } from 'antd';
import { Link, useLocation, useNavigate, useParams } from 'react-router-dom';
import { Typography } from '@mui/material';
import { Space, Table, Tag, Select, Input, InputNumber } from 'antd';
import Box from '@mui/material/Box';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPenToSquare, faCircleCheck, faCaretLeft, faCaretRight } from '@fortawesome/free-solid-svg-icons';
import { Upload, Button, Icon, Form, Modal, Checkbox } from 'antd';
import { TextareaAutosize } from '@mui/base';
import swal from 'sweetalert';
import User from '../../image/undraw_user.png';
import { UploadOutlined, QuestionOutlined } from '@ant-design/icons';
import moment from 'moment';
import dayjs from 'dayjs';
// import Footer from '../components/Footer';
import './patient.css';
import {
    fromsubmitedByApi,
    caspaperMEMBER_IDByApi,
    casepaperGetByApi,
    casepaperUpdateByApi,
    casepaperExcellsheetByApi
} from 'components/Helper/case_paper';
import {
    MemberregidropdownnameSearchApi,
    modelfromByApi,
    registerpatientGetByApi,
    registerpatientUpdateByApi
} from 'components/Helper/member_rgi';
let timeout;
let currentValue;
const { RangePicker } = DatePicker;
// const dateFormat = 'YYYY-MM-DD';
const dateFormat = 'DD-MM-YYYY';

const Casepaper = () => {
    const [placement, SetPlacement] = useState('bottomRight');
    const [pationtnamedata, setpationtpationtnamedata] = useState([]);
    const [registeriddata, setRegisteriddata] = useState([]);
    const [pationtnamevalue, setPationtnameValue] = useState();
    const [pationtnameSelectedName, setPationtnameSelectedName] = useState();
    const [isModalOpenpatientname, setIsModalOpenpatientname] = useState();
    const [editselectedPatient, seteditselectedPatient] = useState();

    const [loadingmodel, setloadingmodel] = useState(false);
    const [loadingregister, setloadingregister] = useState(false);
    let { id } = useParams();
    const [form] = Form.useForm();
    const [formmodal] = Form.useForm();
    const navigate = useNavigate();
    const { TextArea } = Input;

    useEffect(() => {
        if (typeof id !== 'undefined') {
            getregistermemberdatabyid();
        } else {
            form.setFieldValue('REGI_DATE', dayjs(new Date()));
        }
    }, [id]);
    const getregistermemberdatabyid = () => {
        // setloadingregister(true);
        registerpatientGetByApi(id)
            .then(
                async (res) => {
                    console.log(' success');
                    let response = res;
                    response.REGI_DATE = dayjs(response.REGI_DATE, dateFormat); // moment(new Date(response.REGI_DATE)).format('YYYY-MM-DD'); // moment();
                    setRegisteriddata(response);
                    setPationtnameValue(res.MEMBER_ID);
                    seteditselectedPatient(res);
                    form.resetFields();
                    console.log('res', res);
                    // setloadingregister(false);
                },
                (err) => {
                    console.log('err', err);
                    // setloadingregister(false);
                }
            )
            .catch();
    };

    // <==================================================================================>
    // start Model function
    console.log('pationtnamedata', pationtnamedata);
    const onpationtnameSubmitModel = (value) => {
        console.log('dfff', moment(new Date(value.REGI_DATE)).format('DD-MM-YYYY'));
        setloadingmodel(true);
        console.log('success', value);
        if (typeof id === 'undefined') {
            let payloadData = {
                ...value,
                // REGI_DATE: moment(new Date(value.REGI_DATE)).format('YYYY-MM-DD')
                REGI_DATE: moment(new Date(value.REGI_DATE)).format('DD-MM-YYYY')
            };
            modelfromByApi(payloadData).then((res) => {
                console.log('res-----------', res);
                setIsModalOpenpatientname(false);
                navigate('/PationtDetails');
                // navigate('/Casepaper');
                setloadingmodel(false);
                swal('success', ' Patient Add success fully', 'success');
            });

            (err) => {
                console.log(err);
                swal('err', 'Not success fully', 'err');
            };
        } else {
            // //update
            console.log('Success:', value);
            let payloadData = {
                ...value,
                id: id,
                // MEMBER_ID: pationtnamevalue,
                // MEMBER_NAME: pationtnameSelectedName,
                // REGI_DATE: moment(new Date(values.REGI_DATE)).format('YYYY-MM-DD')
                REGI_DATE: moment(new Date(value.REGI_DATE)).format('DD-MM-YYYY')
            };
            setloadingregister(true);
            registerpatientUpdateByApi(payloadData)
                .then(
                    async (res) => {
                        console.log('res', res);
                        console.log(' success');
                        setpationtpationtnamedata(res);
                        swal('register pationt ', 'Update success Fully', 'success');
                        navigate('/PationtDetails');
                        setloadingregister(false);
                    },
                    (err) => {
                        console.log('error', err);
                        setloadingregister(false);
                        swal('register pationt', 'Not updated', 'error');
                    }
                )
                .catch();
        }
    };
    // start Model function
    // <================================== End Api call ==========================================>
    return (
        <>
            <Typography variant="h5" className="mx-2">
                <small className="text-black-50" style={{ fontFamily: 'Poppins' }}>
                    Home
                </small>
                {'/'} <b> Patient Register </b>
            </Typography>
            <br></br>
            <Card className="driver-create-card ">
                <div className="title-main">
                    <h5>
                        {/* <FontAwesomeIcon icon={faCaretLeft} /> */}
                        <span className=" ribbon">register patient </span>
                        {/* <FontAwesomeIcon icon={faCaretRight} /> */}
                    </h5>
                </div>
                <hr className="MuiDivider-root MuiDivider-fullWidth css-1wnin34-MuiDivider-root"></hr>
                {/* <Form name="basic" initialValues={registeriddata} onFinish={onFinishcasepaper} autoComplete="off" form={form}> */}
                <Form name="basic" onFinish={onpationtnameSubmitModel} initialValues={registeriddata} autoComplete="off" form={form}>
                    <Grid item xs={12} container spacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                        <Grid item xs={12} lg={6} md={6} sm={12}>
                            {/* <==============================================================================> */}
                            <Form.Item
                                name="MEMBER_NAME"
                                id="outlined-basic"
                                variant="outlined"
                                // onChange={(e) => {
                                //     setCountrynamdataModel(e.target.value);
                                // }}
                                type="text"
                                rules={[
                                    {
                                        required: true,
                                        message: 'Please Enter your Patient Name!'
                                    }
                                ]}
                                hasFeedback
                            >
                                <TextField
                                    // id="outlined-basic"
                                    allowClear
                                    fullWidth
                                    label="Patient Name"
                                    type="text"
                                />
                            </Form.Item>
                            {/* <===============================================================================> */}
                            <Form.Item
                                fullWidth
                                name="MEMBER_ADD"
                                label="Address"
                                variant="outlined"
                                // rules={[
                                //     {
                                //         required: true,
                                //         message: 'Please input your Address!'
                                //     }
                                // ]}
                            >
                                <TextArea rows={3} fullWidth />
                            </Form.Item>

                            {/* <=========================================================================> */}
                            <Grid item xs={12} container spacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                                <Grid xs={12} lg={6} md={6} sm={12}>
                                    <Form.Item
                                        name="REGI_DATE"
                                        id="outlined-basic"
                                        variant="outlined"
                                        label="Date"
                                        type="Date"
                                        rules={[
                                            {
                                                required: true,
                                                message: 'Please Enter your start Date!'
                                            }
                                        ]}
                                    >
                                        {/* <span>Start Date</span> */}
                                        {/* <TextField id="outlined-basic" type="Date" /> */}
                                        {/* <DatePicker fullWidth placement={placement} format={dateFormat} /> */}
                                        <DatePicker fullWidth defaultValue={dayjs(new Date())} format={dateFormat} placement={placement} />
                                    </Form.Item>
                                </Grid>
                                <Grid xs={12} lg={6} md={6} sm={12}>
                                    {/* <span className="m-2"> Sex</span> */}
                                    <Form.Item
                                        name="SEX"
                                        // id="outlined-basic"
                                        // variant="outlined"
                                        // type="number"
                                        // rules={[
                                        //     {
                                        //         required: true,
                                        //         message: 'Please Enter your Whatsapp Number!'
                                        //     }
                                        // ]}
                                    >
                                        <Radio.Group className="textfont">
                                            <Radio value={1}>Male</Radio>
                                            <Radio value={2}>Female</Radio>
                                        </Radio.Group>
                                    </Form.Item>
                                </Grid>
                            </Grid>
                            {/* <====================================================================> */}
                            <Grid item xs={12} container spacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                                <Grid xs={12} lg={8} md={8} sm={12}>
                                    <Form.Item
                                        name="MEMBER_EMAIL"
                                        className="emailname"
                                        id="outlined-basic"
                                        variant="outlined"
                                        label="E- Email"
                                        type="email"
                                        // rules={[
                                        //     {
                                        //         required: true,
                                        //         message: 'Please Enter Your Email!'
                                        //     },
                                        //     { type: 'email', message: 'please enter a valid email' }
                                        // ]}
                                    >
                                        <Input />
                                        {/* <TextField fullWidth label="Email" type="email" /> */}
                                    </Form.Item>
                                </Grid>
                                <Grid xs={12} lg={4} md={4} sm={12}>
                                    <Form.Item
                                        name="AGE"
                                        id="outlined-basic"
                                        variant="outlined"
                                        className="w-100 "
                                        label="Age"
                                        type="number"
                                        // rules={[
                                        //     {
                                        //         required: true,
                                        //         message: 'Please Enter your Age!'
                                        //     }
                                        // ]}
                                    >
                                        <InputNumber fullWidth />
                                        {/* <TextField label="Age" type="number" fullWidth /> */}
                                    </Form.Item>
                                </Grid>
                            </Grid>
                            <Grid item xs={12} container spacing={1} columnSpacing={{ xs: 1, sm: 2, md: 3 }}>
                                <Grid xs={12} lg={6} md={12} sm={12} xl={6}>
                                    <Form.Item
                                        name="MOBILE_NO"
                                        id="outlined-basic"
                                        variant="outlined"
                                        style={{ width: '100%' }}
                                        label="Mobile No"
                                        type="number"
                                        rules={[
                                            {
                                                required: true,
                                                message: 'Please Enter your Mobile Number!'
                                            },
                                            ({ getFieldValue }) => ({
                                                validator(_, value) {
                                                    console.log('String(value).length', String(value).length);
                                                    if (!value || String(value).length === 10) {
                                                        return Promise.resolve();
                                                    }
                                                    return Promise.reject(new Error('Please Enter 10 characters Mobile Number!'));
                                                }
                                            })
                                        ]}
                                    >
                                        <Input fullWidth />
                                        {/* <TextField fullWidth label="Mobile No" type="number" /> */}
                                    </Form.Item>
                                </Grid>
                                <Grid xs={12} lg={6} md={12} sm={12} xl={6}>
                                    <Form.Item
                                        name="BLOOD"
                                        id="outlined-basic"
                                        variant="outlined"
                                        label="Blood Group"
                                        type="text"
                                        // rules={[
                                        //     {
                                        //         required: true,
                                        //         message: 'Please Enter Your Blood Group!'
                                        //     }
                                        // ]}
                                    >
                                        <Input fullWidth />
                                        {/* <TextField fullWidth label="Blood Group" type="text" /> */}
                                    </Form.Item>
                                </Grid>
                            </Grid>
                            <Form.Item>
                                <Button
                                    type="primary"
                                    htmlType="submit"
                                    className="btn btn-primary m-2 button-hov-add-to-list btn-sm rounded-pill float-end"
                                    loadingmodel={loadingmodel}
                                    // disabled={!email || email === ''}
                                >
                                    Submit
                                </Button>
                            </Form.Item>
                        </Grid>
                        {/* Start image */}
                        <Grid item xs={12} lg={6} md={6} sm={12} className="image-div">
                            <div className="img-fluid">
                                <img src={User} alt="mani" style={{ height: '445px' }} />
                            </div>
                        </Grid>
                        {/* End image */}
                    </Grid>
                </Form>
            </Card>
        </>
    );
};

export default Casepaper;
