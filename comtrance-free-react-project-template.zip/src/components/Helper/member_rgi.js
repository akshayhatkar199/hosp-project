import { axiosPrivate } from './axios';

export const modelfromByApi = async (payloadData) => {
    let res = await axiosPrivate.post('/member_regis', payloadData);
    return res.data;
};
export const membertableshowsearchByApi = async (payloadData) => {
    let res = await axiosPrivate.post('/member_regis/MemberregiSearch', payloadData);
    return res.data;
};
export const MemberregidropdownnameSearchApi = async (payloadData) => {
    let res = await axiosPrivate.post('/member_regis/MemberregidropdownnameSearch', payloadData);
    return res.data;
};
export const MemberregiExcellsheetApi = async (payloadData) => {
    let res = await axiosPrivate.post('/member_regis/MemberregiExcellsheetlist', payloadData);
    return res.data;
};
export const registerpatientCountTotalByApi = async (payloadData) => {
    let res = await axiosPrivate.get('/member_regis/count', payloadData);
    return res.data;
};
export const registerpatientGetByApi = async (id) => {
    let res = await axiosPrivate.get(`/member_regis/${id}`);
    return res.data;
};
export const registerpatientUpdateByApi = async (payloadData) => {
    let res = await axiosPrivate.patch('/member_regis/' + payloadData.id, payloadData);
    return res.data;
};
